let handler = async m => m.reply(`
╭─「 Donasi • Pulsa 」
│ • Smartfren [088212768618]
│ • Saweria [saweria.co/ruby2007]
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
